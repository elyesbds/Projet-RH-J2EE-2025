package servlets;

import dao.EmployerDAO;
import dao.ProjetDAO;
import dao.DepartementDAO;
import dao.AffectationProjetDAO;
import models.Employer;
import models.Projet;
import models.AffectationProjet;
import utils.PermissionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;

/**
 * Servlet pour afficher les projets d'un employé
 */
@WebServlet("/employee-projets/*")
public class EmployeeProjetsServlet extends HttpServlet {
    
    private EmployerDAO employerDAO;
    private ProjetDAO projetDAO;
    private AffectationProjetDAO affectationDAO;
    
    @Override
    public void init() {
        employerDAO = new EmployerDAO();
        projetDAO = new ProjetDAO();
        affectationDAO = new AffectationProjetDAO();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getPathInfo();
        
        if (action == null || action.equals("/")) {
            // Afficher les projets de l'employé
            showEmployeeProjets(request, response);
        } else if (action.equals("/ajouter")) {
            // Afficher le formulaire pour ajouter un projet
            showAjouterProjetForm(request, response);
        } else if (action.equals("/retirer")) {
            // Retirer l'employé d'un projet
            retirerProjet(request, response);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Ajouter l'employé à un projet
        ajouterProjet(request, response);
    }
    
    /**
     * Afficher les projets d'un employé
     */
    private void showEmployeeProjets(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        int employeeId = Integer.parseInt(request.getParameter("employeeId"));
        Employer employee = employerDAO.getById(employeeId);
        
        // Récupérer les affectations de l'employé
        List<AffectationProjet> affectations = affectationDAO.getProjetsByEmployer(employeeId);
        
        // Récupérer les détails des projets
        Map<Integer, Projet> projetsMap = new HashMap<>();
        if (affectations != null) {
            for (AffectationProjet aff : affectations) {
                Projet projet = projetDAO.getById(aff.getIdProjet());
                if (projet != null) {
                    projetsMap.put(projet.getId(), projet);
                }
            }
        }
        
        request.setAttribute("employee", employee);
        request.setAttribute("affectations", affectations);
        request.setAttribute("projetsMap", projetsMap);
        request.getRequestDispatcher("/WEB-INF/views/employees/projets.jsp").forward(request, response);
    }
    
    /**
     * Afficher le formulaire pour ajouter un projet
     */
    private void showAjouterProjetForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Seul l'admin peut ajouter un employé à un projet via cette page
        if (!PermissionUtil.isAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/employees");
            return;
        }
        
        int employeeId = Integer.parseInt(request.getParameter("employeeId"));
        Employer employee = employerDAO.getById(employeeId);
        List<Projet> tousProjets = projetDAO.getAll();
        
        // Filtrer les projets où l'employé n'est pas encore affecté
        List<Projet> projetsDisponibles = new ArrayList<>();
        if (tousProjets != null) {
            for (Projet projet : tousProjets) {
                // Vérifier que l'employé n'est pas déjà affecté
                if (!affectationDAO.isEmployerAffected(employeeId, projet.getId())) {
                    // NOUVELLE VÉRIFICATION : Cohérence département
                    // Si le projet a un département, l'employé doit être du même département
                    if (projet.getIdDepartement() != null) {
                        // Le projet a un département : vérifier la cohérence
                        if (employee.getIdDepartement() != null && 
                            employee.getIdDepartement().equals(projet.getIdDepartement())) {
                            projetsDisponibles.add(projet);
                        }
                        // Si l'employé n'a pas de département, il ne peut pas être affecté à ce projet
                    } else {
                        // Le projet n'a pas de département : tous les employés peuvent être affectés
                        projetsDisponibles.add(projet);
                    }
                }
            }
        }
        
        request.setAttribute("employee", employee);
        request.setAttribute("projets", projetsDisponibles);
        request.getRequestDispatcher("/WEB-INF/views/employees/ajouter-projet-form.jsp").forward(request, response);
    }
    
    /**
     * Ajouter l'employé à un projet
     */
    private void ajouterProjet(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // Seul l'admin peut ajouter
        if (!PermissionUtil.isAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/employees");
            return;
        }
        
        try {
            int employeeId = Integer.parseInt(request.getParameter("employeeId"));
            int projetId = Integer.parseInt(request.getParameter("projetId"));
            
            // NOUVELLE VÉRIFICATION : Cohérence département
            Employer employee = employerDAO.getById(employeeId);
            Projet projet = projetDAO.getById(projetId);
            
            if (employee == null || projet == null) {
                request.getSession().setAttribute("errorMessage", "Employé ou projet introuvable");
                response.sendRedirect(request.getContextPath() + "/employee-projets/ajouter?employeeId=" + employeeId);
                return;
            }
            
            // Si le projet a un département, l'employé doit être du même département
            if (projet.getIdDepartement() != null) {
                if (employee.getIdDepartement() == null) {
                    request.getSession().setAttribute("errorMessage", "Impossible d'affecter cet employé : il n'appartient à aucun département alors que le projet est rattaché à un département.");
                    response.sendRedirect(request.getContextPath() + "/employee-projets/ajouter?employeeId=" + employeeId);
                    return;
                }
                
                if (!employee.getIdDepartement().equals(projet.getIdDepartement())) {
                    request.getSession().setAttribute("errorMessage", "Impossible d'affecter cet employé : il appartient à un département différent de celui du projet.");
                    response.sendRedirect(request.getContextPath() + "/employee-projets/ajouter?employeeId=" + employeeId);
                    return;
                }
            }
            
            // Si tout est OK, créer l'affectation
            AffectationProjet affectation = new AffectationProjet();
            affectation.setIdEmployer(employeeId);
            affectation.setIdProjet(projetId);
            affectation.setDateAffectation(new Date());
            
            boolean success = affectationDAO.create(affectation);
            
            if (success) {
                request.getSession().setAttribute("successMessage", "Employé affecté au projet avec succès");
            } else {
                request.getSession().setAttribute("errorMessage", "Erreur lors de l'affectation");
            }
            
            response.sendRedirect(request.getContextPath() + "/employee-projets?employeeId=" + employeeId);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.getSession().setAttribute("errorMessage", "Erreur : " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/employees");
        }
    }
    /**
     * Retirer l'employé d'un projet
     */
    private void retirerProjet(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        // Seul l'admin peut retirer
        if (!PermissionUtil.isAdmin(request)) {
            response.sendRedirect(request.getContextPath() + "/employees");
            return;
        }
        
        int affectationId = Integer.parseInt(request.getParameter("affectationId"));
        int employeeId = Integer.parseInt(request.getParameter("employeeId"));
        
        affectationDAO.delete(affectationId);
        response.sendRedirect(request.getContextPath() + "/employee-projets?employeeId=" + employeeId);
    }
}