package dao;

import models.Projet;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import utils.HibernateUtil;
import java.util.List;
import java.util.Calendar;
import java.util.Date;

/**
 * DAO pour gérer les opérations sur les projets
 */
public class ProjetDAO {
    
    /**
     * Créer un nouveau projet
     */
    public boolean create(Projet projet) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.persist(projet);
            transaction.commit();
            return true;
        } catch (org.hibernate.exception.ConstraintViolationException e) {
            // Erreur de doublon (nom de projet déjà existant)
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Récupérer un projet par son ID
     */
    public Projet getById(Integer id) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.get(Projet.class, id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Récupérer tous les projets
     */
    public List<Projet> getAll() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            return session.createQuery("FROM Projet", Projet.class).list();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Mettre à jour un projet
     */
    public boolean update(Projet projet) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.merge(projet);
            transaction.commit();
            return true;
        } catch (org.hibernate.exception.ConstraintViolationException e) {
            // Erreur de doublon (nom de projet déjà existant)
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Supprimer un projet
     */
    public boolean delete(Integer id) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            Projet projet = session.get(Projet.class, id);
            if (projet != null) {
                session.remove(projet);
                transaction.commit();
                return true;
            }
            return false;
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Récupérer un projet par son nom
     */
    public Projet getByNomProjet(String nomProjet) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            String hql = "FROM Projet WHERE LOWER(nomProjet) = LOWER(:nomProjet)";
            Query<Projet> query = session.createQuery(hql, Projet.class);
            query.setParameter("nomProjet", nomProjet);
            return query.uniqueResult();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Récupérer les projets par état
     */
    public List<Projet> getByEtat(String etat) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            String hql = "FROM Projet WHERE etatProjet = :etat";
            Query<Projet> query = session.createQuery(hql, Projet.class);
            query.setParameter("etat", etat);
            return query.list();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Récupérer les projets par département
     */
    public List<Projet> getByDepartement(Integer idDepartement) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            String hql = "FROM Projet WHERE idDepartement = :idDept";
            Query<Projet> query = session.createQuery(hql, Projet.class);
            query.setParameter("idDept", idDepartement);
            return query.list();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Récupérer les projets où l'employé est chef de projet
     */
    public List<Projet> getByChefProjet(Integer chefProjetId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            String hql = "FROM Projet WHERE chefProjet = :chefId";
            Query<Projet> query = session.createQuery(hql, Projet.class);
            query.setParameter("chefId", chefProjetId);
            return query.list();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Mettre à jour automatiquement l'état d'un projet selon ses dates
     */
    public void updateEtatAutomatique(Projet projet) {
        if (projet == null || projet.getDateDebut() == null) {
            return;
        }
        
        // Si le projet est ANNULE, ne rien changer
        if ("ANNULE".equals(projet.getEtatProjet())) {
            return;
        }
        
        try {
            Date aujourdhui = new Date();
            
            // Normaliser les dates (ignorer l'heure)
            Calendar calDebut = Calendar.getInstance();
            calDebut.setTime(projet.getDateDebut());
            calDebut.set(Calendar.HOUR_OF_DAY, 0);
            calDebut.set(Calendar.MINUTE, 0);
            calDebut.set(Calendar.SECOND, 0);
            calDebut.set(Calendar.MILLISECOND, 0);
            
            Calendar calAujourdhui = Calendar.getInstance();
            calAujourdhui.setTime(aujourdhui);
            calAujourdhui.set(Calendar.HOUR_OF_DAY, 0);
            calAujourdhui.set(Calendar.MINUTE, 0);
            calAujourdhui.set(Calendar.SECOND, 0);
            calAujourdhui.set(Calendar.MILLISECOND, 0);
            
            Date dateDebut = calDebut.getTime();
            aujourdhui = calAujourdhui.getTime();
            
            String nouvelEtat = projet.getEtatProjet();
            
            // Si la date de début est dans le futur
            if (dateDebut.after(aujourdhui)) {
                nouvelEtat = "PAS_COMMENCE";
            }
            // Si la date de début est aujourd'hui ou dans le passé
            else {
                // Si la date de fin prévue est passée
                if (projet.getDateFinPrevue() != null) {
                    Calendar calFin = Calendar.getInstance();
                    calFin.setTime(projet.getDateFinPrevue());
                    calFin.set(Calendar.HOUR_OF_DAY, 0);
                    calFin.set(Calendar.MINUTE, 0);
                    calFin.set(Calendar.SECOND, 0);
                    calFin.set(Calendar.MILLISECOND, 0);
                    Date dateFin = calFin.getTime();
                    
                    if (dateFin.before(aujourdhui)) {
                        nouvelEtat = "TERMINE";
                    } else {
                        nouvelEtat = "EN_COURS";
                    }
                } else {
                    nouvelEtat = "EN_COURS";
                }
            }
            
            // Mettre à jour si l'état a changé
            if (!nouvelEtat.equals(projet.getEtatProjet())) {
                projet.setEtatProjet(nouvelEtat);
                update(projet);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}